package com.example.receivejsondatafromarduino;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bluetooth myBluetooth = new Bluetooth();
        myBluetooth.connectToBluetooth();
        String abc = "";
        char a;
        try {
            abc = myBluetooth.readJsonStringData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("printing in the mainActivity = "+abc);
        try {
            myBluetooth.closeBluetooth();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
